package com.example.medicare.alarm;

import com.example.medicare.addmedicine.BasePresenter;
import com.example.medicare.addmedicine.BaseView;
import com.example.medicare.data.source.History;
import com.example.medicare.data.source.MedicineAlarm;

/**
 * Created by gautam on 13/07/17.
 */

public interface ReminderContract {

    interface View extends BaseView<Presenter> {

        void showMedicine(MedicineAlarm medicineAlarm);

        void showNoData();

        boolean isActive();

        void onFinish();

    }

    interface Presenter extends BasePresenter {

        void finishActivity();

        void onStart(long id);

        void loadMedicineById(long id);

        void addPillsToHistory(History history);

    }
}
