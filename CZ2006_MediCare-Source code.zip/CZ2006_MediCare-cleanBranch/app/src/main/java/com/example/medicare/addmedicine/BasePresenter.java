package com.example.medicare.addmedicine;;

public interface BasePresenter {

    void start();
}
